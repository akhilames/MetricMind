"""
Unit tests for the governance boundary in agent/tools/semantic_api_tool.py.
No LLM or running Cube.dev server required for the rejection cases.

Usage: python -m pytest tests/api_translation_tests.py -v
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "agent"))

from tools.semantic_api_tool import query_semantic_layer  # noqa: E402


def test_rejects_unknown_measure():
    result = query_semantic_layer.invoke({
        "measures": ["Revenue.totallyMadeUp"],
        "dimensions": [],
    })
    assert result.get("error") == "governance_violation"


def test_rejects_unknown_dimension():
    result = query_semantic_layer.invoke({
        "measures": ["Revenue.total"],
        "dimensions": ["Revenue.secretInternalField"],
    })
    assert result.get("error") == "governance_violation"


def test_allows_governed_measure_shape():
    # We only check that a *valid* request passes the governance check and
    # is allowed through to the HTTP call — not that Cube.dev is running.
    from tools import semantic_api_tool

    allowed = "Revenue.total" in semantic_api_tool.ALLOWED_MEASURES
    assert allowed is True
