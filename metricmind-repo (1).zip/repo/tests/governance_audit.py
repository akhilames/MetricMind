"""
Governance audit: proves that asking the semantic layer for the same metric
twice returns the exact same number, with no LLM involved. This is what
should be run in CI before every deploy of the semantic layer.

Usage (with the Cube.dev dev server running on :4000):
    python tests/governance_audit.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "agent"))

from tools.semantic_api_tool import query_semantic_layer  # noqa: E402


def run_query():
    return query_semantic_layer.invoke({
        "measures": ["Margin.grossMargin", "Margin.marginPct"],
        "dimensions": ["Margin.region"],
        "filters_region": "Europe",
    })


def main():
    result_1 = run_query()
    result_2 = run_query()

    if "error" in result_1:
        print(f"FAIL: semantic layer returned an error: {result_1}")
        sys.exit(1)

    if result_1 == result_2:
        print("PASS: identical query returned identical results across two calls.")
        print(result_1)
        sys.exit(0)
    else:
        print("FAIL: same query returned different results!")
        print("Call 1:", result_1)
        print("Call 2:", result_2)
        sys.exit(1)


if __name__ == "__main__":
    main()
