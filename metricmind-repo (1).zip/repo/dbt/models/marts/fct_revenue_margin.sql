-- The single governed table the Semantic Layer points to.
-- Every "Revenue" / "Margin" number in MetricMind traces back to this model —
-- there is exactly one place the formula is defined.
with base as (
    select * from {{ ref('stg_transactions') }}
),

aggregated as (
    select
        region,
        product_line,
        quarter_start,
        sum(revenue)                                   as total_revenue,
        sum(cost_of_goods)                              as total_cost_of_goods,
        sum(shipping_cost)                              as total_shipping_cost,
        sum(cost_of_goods) + sum(shipping_cost)          as total_cost,
        sum(revenue) - (sum(cost_of_goods) + sum(shipping_cost)) as gross_margin,
        round(
            100.0 * (sum(revenue) - (sum(cost_of_goods) + sum(shipping_cost)))
            / nullif(sum(revenue), 0),
            2
        ) as margin_pct
    from base
    group by 1, 2, 3
)

select * from aggregated
