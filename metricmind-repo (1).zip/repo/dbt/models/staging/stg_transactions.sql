-- Cleans and types the raw transaction feed before it reaches any mart.
with source as (
    select * from {{ ref('raw_transactions') }}
),

cleaned as (
    select
        transaction_id,
        cast(transaction_date as date)         as transaction_date,
        date_trunc('quarter', transaction_date) as quarter_start,
        trim(region)                            as region,
        trim(product_line)                      as product_line,
        customer_id,
        cast(revenue as decimal(18,2))          as revenue,
        cast(cost_of_goods as decimal(18,2))    as cost_of_goods,
        cast(shipping_cost as decimal(18,2))    as shipping_cost
    from source
    where revenue is not null
)

select * from cleaned
