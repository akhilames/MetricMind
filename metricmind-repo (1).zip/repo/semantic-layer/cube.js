// Cube.dev entry config.
// Points at the DuckDB file that dbt builds (../dbt/metricmind.duckdb).
// Swap CUBEJS_DB_TYPE / connection env vars to target Snowflake or Databricks in production.
module.exports = {
  dbType: () => process.env.CUBEJS_DB_TYPE || 'duckdb',

  // Every metric MUST come from a cube — this is what stops the agent
  // from ever inventing a join or a raw SQL query of its own.
  contextToOrchestratorId: () => 'metricmind',
};
