// The single mathematical definition of "Margin".
// gross_margin and margin_pct are computed once, in dbt (fct_revenue_margin) —
// this cube only exposes them, it never recomputes the formula.
cube(`Margin`, {
  sql: `SELECT * FROM main.fct_revenue_margin`,

  measures: {
    grossMargin: {
      sql: `gross_margin`,
      type: `sum`,
      title: `Gross Margin ($)`,
    },
    marginPct: {
      // Recomputed from the summed components so it aggregates correctly
      // across any combination of filters (never averaged directly).
      sql: `100.0 * SUM(gross_margin) / NULLIF(SUM(total_revenue), 0)`,
      type: `number`,
      title: `Gross Margin (%)`,
    },
    totalCostOfGoods: {
      sql: `total_cost_of_goods`,
      type: `sum`,
      title: `Cost of Goods`,
    },
    totalShippingCost: {
      sql: `total_shipping_cost`,
      type: `sum`,
      title: `Shipping Cost`,
      description: `Broken out separately so the agent can root-cause a margin drop
        (e.g. "shipping costs rose" vs "material costs rose") without guessing.`,
    },
  },

  dimensions: {
    region: {
      sql: `region`,
      type: `string`,
    },
    productLine: {
      sql: `product_line`,
      type: `string`,
    },
    quarter: {
      sql: `quarter_start`,
      type: `time`,
    },
  },
});
