// The single mathematical definition of "Revenue".
// The agent is only ever allowed to ask for `Revenue.total` — it cannot
// re-derive this formula itself, so Finance and Sales always agree.
cube(`Revenue`, {
  sql: `SELECT * FROM main.fct_revenue_margin`,

  measures: {
    total: {
      sql: `total_revenue`,
      type: `sum`,
      title: `Total Revenue`,
      description: `Sum of all transaction revenue, governed — the one number Finance and Sales both use.`,
    },
  },

  dimensions: {
    region: {
      sql: `region`,
      type: `string`,
    },
    productLine: {
      sql: `product_line`,
      type: `string`,
    },
    quarter: {
      sql: `quarter_start`,
      type: `time`,
    },
  },
});
