"use client";

import { useState } from "react";

type Message = {
  role: "user" | "assistant";
  content: string;
  apiCall?: Record<string, unknown> | null;
};

const AGENT_API_URL = process.env.NEXT_PUBLIC_AGENT_API_URL || "http://localhost:8000";

export default function ChatWindow() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content:
        "Ask me anything about Revenue or Margin \u2014 e.g. \u201cWhy did our European margins drop last quarter?\u201d",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [openApiCallFor, setOpenApiCallFor] = useState<number | null>(null);

  async function send() {
    const question = input.trim();
    if (!question || loading) return;

    setMessages((m) => [...m, { role: "user", content: question }]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch(`${AGENT_API_URL}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: question }),
      });
      const data = await res.json();
      setMessages((m) => [
        ...m,
        { role: "assistant", content: data.answer, apiCall: data.api_call },
      ]);
    } catch (err) {
      setMessages((m) => [
        ...m,
        {
          role: "assistant",
          content:
            "Couldn't reach the MetricMind agent API. Is `agent/app.py` running on port 8000?",
        },
      ]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ maxWidth: 720, margin: "0 auto", padding: "2rem 1rem" }}>
      <h1 style={{ color: "#1E2761", fontSize: 28, marginBottom: 4 }}>MetricMind</h1>
      <p style={{ color: "#5B6485", marginTop: 0, marginBottom: 24 }}>
        Agentic Semantic BI \u2014 every number below came from the governed semantic layer.
      </p>

      <div
        style={{
          background: "white",
          borderRadius: 12,
          padding: 20,
          minHeight: 320,
          boxShadow: "0 1px 3px rgba(30,39,97,0.12)",
        }}
      >
        {messages.map((m, i) => (
          <div key={i} style={{ marginBottom: 16 }}>
            <div
              style={{
                fontSize: 11,
                fontWeight: 700,
                letterSpacing: 1,
                color: m.role === "user" ? "#B8860B" : "#1E2761",
                marginBottom: 4,
              }}
            >
              {m.role === "user" ? "YOU" : "METRICMIND"}
            </div>
            <div style={{ color: "#1B1F3B", lineHeight: 1.5, whiteSpace: "pre-wrap" }}>
              {m.content}
            </div>
            {m.apiCall && (
              <div style={{ marginTop: 6 }}>
                <button
                  onClick={() => setOpenApiCallFor(openApiCallFor === i ? null : i)}
                  style={{
                    fontSize: 12,
                    color: "#1E2761",
                    background: "#EDF0FA",
                    border: "none",
                    borderRadius: 6,
                    padding: "4px 10px",
                    cursor: "pointer",
                  }}
                >
                  {openApiCallFor === i ? "Hide API Call" : "View API Call"}
                </button>
                {openApiCallFor === i && (
                  <pre
                    style={{
                      background: "#1B1F3B",
                      color: "#CADCFC",
                      fontSize: 11.5,
                      padding: 12,
                      borderRadius: 8,
                      overflowX: "auto",
                      marginTop: 8,
                    }}
                  >
                    {JSON.stringify(m.apiCall, null, 2)}
                  </pre>
                )}
              </div>
            )}
          </div>
        ))}
        {loading && <div style={{ color: "#5B6485", fontSize: 13 }}>Querying semantic layer...</div>}
      </div>

      <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
          placeholder="Ask about Revenue or Margin..."
          style={{
            flex: 1,
            padding: "12px 14px",
            borderRadius: 8,
            border: "1px solid #CADCFC",
            fontSize: 14,
          }}
        />
        <button
          onClick={send}
          disabled={loading}
          style={{
            background: "#1E2761",
            color: "white",
            border: "none",
            borderRadius: 8,
            padding: "0 20px",
            fontWeight: 600,
            cursor: "pointer",
          }}
        >
          Ask
        </button>
      </div>
    </div>
  );
}
