export const metadata = {
  title: "MetricMind",
  description: "Agentic Semantic BI Engine",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, fontFamily: "system-ui, sans-serif", background: "#F4F6FC" }}>
        {children}
      </body>
    </html>
  );
}
