"""
FastAPI service that the Next.js chat UI calls.

POST /chat {"message": "..."} -> {"answer": "...", "api_call": {...}}
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from orchestrator import ask

app = FastAPI(title="MetricMind Agent API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatRequest(BaseModel):
    message: str


class ChatResponse(BaseModel):
    answer: str
    api_call: dict | None = None


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    if not req.message.strip():
        raise HTTPException(status_code=400, detail="message must not be empty")
    result = ask(req.message)
    return ChatResponse(**result)


@app.get("/health")
def health():
    return {"status": "ok"}
