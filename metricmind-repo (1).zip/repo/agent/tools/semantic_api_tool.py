"""
The agent's ONLY data-access tool.

It never touches the warehouse or writes SQL. Every number it returns comes
from a POST to Cube.dev's REST API, which in turn resolves against the
governed metric definitions in semantic-layer/schema/*.js.
"""
import os
import time
import requests
import jwt
from typing import Optional
from langchain.tools import tool

CUBEJS_API_URL = os.environ.get("CUBEJS_API_URL", "http://localhost:4000/cubejs-api/v1")
CUBEJS_API_SECRET = os.environ.get("CUBEJS_API_SECRET", "change_me_local_dev_secret")

# Metrics the agent is allowed to ask for. Anything outside this list is
# rejected before it ever reaches the semantic layer — this is the
# governance boundary, enforced in code, not just in the prompt.
ALLOWED_MEASURES = {
    "Revenue.total",
    "Margin.grossMargin",
    "Margin.marginPct",
    "Margin.totalCostOfGoods",
    "Margin.totalShippingCost",
}
ALLOWED_DIMENSIONS = {"Revenue.region", "Revenue.productLine", "Margin.region", "Margin.productLine"}
ALLOWED_TIME_DIMENSIONS = {"Revenue.quarter", "Margin.quarter"}


def _cube_token() -> str:
    """Cube.dev auth token, signed with the shared API secret."""
    return jwt.encode({"iat": int(time.time())}, CUBEJS_API_SECRET, algorithm="HS256")


def _last_api_call_holder():
    # Simple mutable holder so app.py can surface "View API Call" transparency
    # without threading extra state through the LangChain agent executor.
    if not hasattr(_last_api_call_holder, "value"):
        _last_api_call_holder.value = None
    return _last_api_call_holder


@tool
def query_semantic_layer(
    measures: list[str],
    dimensions: Optional[list[str]] = None,
    date_range: Optional[str] = None,
    filters_region: Optional[str] = None,
) -> dict:
    """
    Query the governed semantic layer (Cube.dev) for one or more metrics.

    measures: e.g. ["Margin.grossMargin", "Margin.marginPct"]
    dimensions: e.g. ["Margin.region", "Margin.quarter"]
    date_range: e.g. "last 2 quarters" or an ISO range "2025-07-01,2025-12-31"
    filters_region: optional exact region filter, e.g. "Europe"

    Returns the raw JSON result from Cube.dev. Never fabricate numbers —
    always call this tool for anything numeric.
    """
    measures = measures or []
    dimensions = dimensions or []

    bad_measures = [m for m in measures if m not in ALLOWED_MEASURES]
    bad_dims = [d for d in dimensions if d not in ALLOWED_DIMENSIONS and d not in ALLOWED_TIME_DIMENSIONS]
    if bad_measures or bad_dims:
        return {
            "error": "governance_violation",
            "detail": f"Unknown metric(s)/dimension(s) requested: {bad_measures + bad_dims}. "
                      f"Only governed metrics defined in the semantic layer may be queried.",
        }

    query: dict = {"measures": measures, "dimensions": dimensions}

    time_dim = next((d for d in dimensions if d in ALLOWED_TIME_DIMENSIONS), None)
    if time_dim and date_range:
        query["timeDimensions"] = [{"dimension": time_dim, "dateRange": date_range}]

    if filters_region:
        region_dim = "Margin.region" if any(m.startswith("Margin.") for m in measures) else "Revenue.region"
        query["filters"] = [{"member": region_dim, "operator": "equals", "values": [filters_region]}]

    resp = requests.post(
        f"{CUBEJS_API_URL}/load",
        headers={"Authorization": _cube_token(), "Content-Type": "application/json"},
        json={"query": query},
        timeout=15,
    )
    resp.raise_for_status()
    payload = resp.json()

    _last_api_call_holder().value = {"endpoint": f"{CUBEJS_API_URL}/load", "query": query}
    return payload


def get_last_api_call() -> Optional[dict]:
    """Used by the FastAPI layer to power the 'View API Call' transparency button."""
    return _last_api_call_holder().value
