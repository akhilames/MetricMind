"""
MetricMind agent orchestrator.

Wires a tool-calling LLM agent to the ONE tool it's allowed to use:
query_semantic_layer (agent/tools/semantic_api_tool.py). The agent can only
ever retrieve numbers that already exist, governed, in the semantic layer —
it cannot write or run its own SQL.
"""
import os
from pathlib import Path

from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

from tools.semantic_api_tool import query_semantic_layer, get_last_api_call

SYSTEM_PROMPT = Path(__file__).parent.joinpath("prompts/system_prompt.txt").read_text()

LLM_PROVIDER = os.environ.get("MM_LLM_PROVIDER", "anthropic")  # "anthropic" | "openai"


def _build_llm():
    if LLM_PROVIDER == "openai":
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(model=os.environ.get("MM_LLM_MODEL", "gpt-4o"), temperature=0)
    from langchain_anthropic import ChatAnthropic
    return ChatAnthropic(model=os.environ.get("MM_LLM_MODEL", "claude-sonnet-4-6"), temperature=0)


def build_agent_executor() -> AgentExecutor:
    llm = _build_llm()
    tools = [query_semantic_layer]

    prompt = ChatPromptTemplate.from_messages([
        ("system", SYSTEM_PROMPT),
        MessagesPlaceholder("chat_history", optional=True),
        ("human", "{input}"),
        MessagesPlaceholder("agent_scratchpad"),
    ])

    agent = create_tool_calling_agent(llm, tools, prompt)
    return AgentExecutor(agent=agent, tools=tools, verbose=True, max_iterations=6)


def ask(question: str) -> dict:
    """Run one question through the agent and return the answer plus the raw
    semantic-layer API call(s) it made, for the UI's transparency panel."""
    executor = build_agent_executor()
    result = executor.invoke({"input": question})
    return {
        "answer": result["output"],
        "api_call": get_last_api_call(),
    }


if __name__ == "__main__":
    import sys
    q = " ".join(sys.argv[1:]) or "Why did our European margins drop last quarter?"
    out = ask(q)
    print("\n--- ANSWER ---")
    print(out["answer"])
    print("\n--- LAST SEMANTIC LAYER CALL ---")
    print(out["api_call"])
