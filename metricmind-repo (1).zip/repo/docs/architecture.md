# MetricMind Architecture

```
User Question
     │
     ▼
Conversational BI UI (Next.js)         web/app/chat, web/components/ChatWindow.tsx
     │  POST /chat { message }
     ▼
Agent API (FastAPI)                    agent/app.py
     │
     ▼
LangChain Agent Orchestrator           agent/orchestrator.py
     │  calls the ONE tool it's given
     ▼
query_semantic_layer tool              agent/tools/semantic_api_tool.py
     │  governance allow-list check, then POST /cubejs-api/v1/load
     ▼
Semantic Layer (Cube.dev)              semantic-layer/schema/Revenue.js, Margin.js
     │  resolves the governed SQL
     ▼
Governed Mart (dbt)                    dbt/models/marts/fct_revenue_margin.sql
     │
     ▼
Warehouse (DuckDB locally / Snowflake in prod)
```

## Why the agent can't hallucinate a number

1. `query_semantic_layer` is the agent's **only** tool — there is no SQL tool, no
   raw-warehouse-connection tool.
2. The tool itself validates every `measures` / `dimensions` value against an
   allow-list (`ALLOWED_MEASURES`, `ALLOWED_DIMENSIONS`) before it will call
   Cube.dev at all — this is enforced in code, not just prompted.
3. Cube.dev resolves each measure against exactly one SQL definition, defined
   once in `semantic-layer/schema/*.js`, which itself points at exactly one
   dbt mart (`fct_revenue_margin`).
4. That mart has exactly one formula for margin: `revenue - (cost_of_goods +
   shipping_cost)`, computed once in `dbt/models/marts/fct_revenue_margin.sql`.

Ask the same question twice, in two different sessions, and you get the same
number — proven by `tests/governance_audit.py`.

## Root-cause / multi-step reasoning

The system prompt (`agent/prompts/system_prompt.txt`) instructs the agent
that when a metric like margin has moved, it should issue a **second**
`query_semantic_layer` call breaking the number down into
`Margin.totalCostOfGoods` vs `Margin.totalShippingCost` across the two
periods being compared, so it can name the driver instead of just the
headline number.

## Local demo dataset

`dbt/seeds/raw_transactions.csv` contains mock Q3 vs Q4 2025 transactions.
Europe's shipping cost roughly doubles quarter-over-quarter while cost of
goods stays flat — so asking *"Why did our European margins drop last
quarter?"* has a real, discoverable answer: gross margin falls from ~46% to
~38%, driven almost entirely by shipping, not materials.
